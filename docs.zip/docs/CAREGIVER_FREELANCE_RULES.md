# Sistema de Cuidadores Freelancers y Scoring - Contexto Argentino
